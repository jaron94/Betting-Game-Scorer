#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @import R6
#' @import shinyMobile
#' @importFrom gargoyle init
#' @importFrom gargoyle trigger
#' @importFrom gargoyle watch
#' @importFrom rlang .data
## usethis namespace: end
NULL
