export declare const IN_NODE: boolean;
export declare let loadScript: (url: string) => Promise<void>;
