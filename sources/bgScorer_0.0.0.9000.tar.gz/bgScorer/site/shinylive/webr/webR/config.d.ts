export declare const BASE_URL: string;
export declare const PKG_BASE_URL = "https://repo.r-wasm.org";
