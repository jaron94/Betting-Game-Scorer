library(testthat)
library(bgScorer)

test_check("bgScorer")
