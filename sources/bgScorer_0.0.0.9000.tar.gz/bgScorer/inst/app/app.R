# Launch the ShinyApp (Do not remove this comment)
options(bgScorer.mobile = TRUE) # nolint undesirable_function_linter
bgScorer::run_app()
